import "./UserModel.js";
import "./db.js";
import "./UserController.js";

console.log("Running app.js");
