import "./UserModel.js";
import "./db.js";
import "./query.js";

console.log("Running app.js");
