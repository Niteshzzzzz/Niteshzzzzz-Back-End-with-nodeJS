import "./UserModel.js";
import "./db.js";
import "./document.js";

console.log("Running app.js");
