Mongoose is a popular ODM (Object Data Modeling) library for MongoDB

ODM (Object Data Modeling)
ODM (Object Document Modeling)
ODM (Object Document Mapping)
ODM (Object Document Mapper)