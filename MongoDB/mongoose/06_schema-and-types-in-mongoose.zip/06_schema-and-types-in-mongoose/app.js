import "./UserModel.js";
import "./db.js";


console.log('Running app.js');