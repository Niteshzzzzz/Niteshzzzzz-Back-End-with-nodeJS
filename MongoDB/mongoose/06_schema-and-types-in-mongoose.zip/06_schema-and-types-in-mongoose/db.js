import mongoose from "mongoose";

mongoose.connect("mongodb://admin:admin@localhost");
console.log("Database connection requested");

console.log("Running DB.js");
