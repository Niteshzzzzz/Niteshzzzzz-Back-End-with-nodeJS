const users = [
  {
    name: "Alice",
    info: "Hello, I am a string",
    age: 25,
  },
  {
    name: "Bob",
    info: 42,
    age: 30,
  },
  {
    name: "Charlie",
    info: true,
    age: 35,
  },
  {
    name: "Diana",
    info: { hobby: "Reading", level: "Expert" },
    age: 28,
  },
];
