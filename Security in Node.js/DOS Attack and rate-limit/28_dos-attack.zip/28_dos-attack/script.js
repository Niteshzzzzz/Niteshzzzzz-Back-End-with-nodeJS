setInterval(() => {
  fetch("http://localhost:4000/register");
}, 100);
