// const a = Buffer.from(
//   "eyJpZCI6IjY3OTZiYzIyNDU5ZDRlMTM4OGMzNjFlOSIsImV4cGlyeSI6MTc0MzAzNjQ5MX0",
//   "base64url"
// ).toString();

// const a = Buffer.from(
//   '{"id":"6796bc22459d4e1388c361e9","expiry":1751676491}'
// ).toString("base64url");

// console.log(a);
